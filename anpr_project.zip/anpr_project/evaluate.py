"""
Evaluate ANPR accuracy against ground-truth labels.
Works with UFPR-ALPR dataset label format or a custom CSV.

Ground-truth CSV format expected:
    image_name, true_plate
    ex: 001.jpg, ABC1234

Run:
    python evaluate.py --gt ground_truth.csv --results output/results.csv
"""

import csv
import argparse
import os
import re


def clean(text: str) -> str:
    return re.sub(r'[^A-Z0-9]', '', str(text).upper())


def load_csv(path: str, key_col: int, val_col: int) -> dict:
    data = {}
    with open(path, newline='') as f:
        reader = csv.reader(f)
        next(reader, None)          # skip header
        for row in reader:
            if len(row) <= max(key_col, val_col):
                continue
            k = os.path.basename(row[key_col].strip())
            v = clean(row[val_col])
            data[k] = v
    return data


def cer(pred: str, gt: str) -> float:
    """Character Error Rate (Levenshtein / len(gt))."""
    if not gt:
        return 1.0 if pred else 0.0
    import difflib
    matcher = difflib.SequenceMatcher(None, pred, gt)
    edits = len(pred) + len(gt) - 2 * sum(
        t.size for t in matcher.get_matching_blocks()
    )
    return edits / max(len(gt), 1)


def evaluate(gt_path: str, results_path: str):
    gt      = load_csv(gt_path,      key_col=0, val_col=1)
    results = load_csv(results_path, key_col=0, val_col=1)

    total        = len(gt)
    exact_match  = 0
    detected     = 0
    cer_scores   = []
    errors       = []

    for img, true_plate in gt.items():
        pred_plate = results.get(img, "")

        if pred_plate and pred_plate != "NOT_DETECTED":
            detected += 1
            c = cer(pred_plate, true_plate)
            cer_scores.append(c)

            if pred_plate == true_plate:
                exact_match += 1
            else:
                errors.append((img, true_plate, pred_plate, round(c, 3)))
        else:
            cer_scores.append(1.0)
            errors.append((img, true_plate, "NOT_DETECTED", 1.0))

    detection_rate = detected / total * 100 if total else 0
    accuracy       = exact_match / total * 100 if total else 0
    avg_cer        = sum(cer_scores) / len(cer_scores) if cer_scores else 1.0

    print("=" * 50)
    print("          ANPR EVALUATION REPORT")
    print("=" * 50)
    print(f"  Total images       : {total}")
    print(f"  Plates detected    : {detected}  ({detection_rate:.1f}%)")
    print(f"  Exact matches      : {exact_match}")
    print(f"  Accuracy (exact)   : {accuracy:.2f}%")
    print(f"  Avg CER            : {avg_cer:.4f}  (lower = better)")
    print("=" * 50)

    if errors:
        print(f"\nTop 10 errors:")
        print(f"  {'Image':<20} {'True':>10} {'Pred':>12} {'CER':>6}")
        print("  " + "-" * 52)
        for img, t, p, c in sorted(errors, key=lambda x: -x[3])[:10]:
            print(f"  {img:<20} {t:>10} {p:>12} {c:>6.3f}")

    return {"accuracy": accuracy, "detection_rate": detection_rate, "avg_cer": avg_cer}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="ANPR Evaluation")
    parser.add_argument("--gt",      required=True, help="Ground truth CSV path")
    parser.add_argument("--results", required=True, help="Results CSV from detect_plate.py")
    args = parser.parse_args()

    if not os.path.exists(args.gt):
        print(f"[ERROR] Ground truth file not found: {args.gt}")
    elif not os.path.exists(args.results):
        print(f"[ERROR] Results file not found: {args.results}")
    else:
        evaluate(args.gt, args.results)
