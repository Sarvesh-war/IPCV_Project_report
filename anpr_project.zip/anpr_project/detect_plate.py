"""
Vehicle Number Plate Recognition (ANPR)
Algorithm : Haar Cascade Plate Detection + EasyOCR
Dataset   : UFPR-ALPR (4500 images) or own plate photos
Tools     : Python + OpenCV + EasyOCR
"""

import cv2
import easyocr
import os
import csv
import re
import time
from datetime import datetime

# ─────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────
HAAR_CASCADE_PATH = cv2.data.haarcascades + "haarcascade_russian_plate_number.xml"
OUTPUT_DIR        = "output"
RESULTS_CSV       = os.path.join(OUTPUT_DIR, "results.csv")

os.makedirs(OUTPUT_DIR, exist_ok=True)

# ─────────────────────────────────────────────
# INIT
# ─────────────────────────────────────────────
print("[INFO] Loading Haar Cascade detector...")
plate_cascade = cv2.CascadeClassifier(HAAR_CASCADE_PATH)
if plate_cascade.empty():
    raise IOError("[ERROR] Could not load Haar Cascade XML. Check path.")

print("[INFO] Loading EasyOCR (first run downloads model ~100MB)...")
reader = easyocr.Reader(['en'], gpu=False)   # set gpu=True if CUDA available
print("[INFO] EasyOCR ready.\n")


# ─────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────
def clean_plate_text(text: str) -> str:
    """Remove spaces, keep only alphanumeric characters."""
    return re.sub(r'[^A-Z0-9]', '', text.upper()).strip()


def detect_and_read(image_path: str, save_crops: bool = True):
    """
    Detect licence plate region with Haar Cascade,
    then read text with EasyOCR.

    Returns: list of dicts  {plate_text, confidence, bbox, crop_path}
    """
    img = cv2.imread(image_path)
    if img is None:
        print(f"  [WARN] Cannot read image: {image_path}")
        return []

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    # Enhance contrast for better detection
    gray = cv2.equalizeHist(gray)

    plates = plate_cascade.detectMultiScale(
        gray,
        scaleFactor=1.1,
        minNeighbors=4,
        minSize=(60, 20),
        maxSize=(400, 120)
    )

    results = []
    base_name = os.path.splitext(os.path.basename(image_path))[0]

    for idx, (x, y, w, h) in enumerate(plates):
        # Add slight padding
        pad = 5
        x1 = max(0, x - pad)
        y1 = max(0, y - pad)
        x2 = min(img.shape[1], x + w + pad)
        y2 = min(img.shape[0], y + h + pad)

        crop = img[y1:y2, x1:x2]

        # Pre-process crop for OCR
        crop_gray  = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
        crop_gray  = cv2.resize(crop_gray, None, fx=2, fy=2,
                                interpolation=cv2.INTER_CUBIC)
        _, crop_bin = cv2.threshold(crop_gray, 0, 255,
                                    cv2.THRESH_BINARY + cv2.THRESH_OTSU)

        # Run EasyOCR
        ocr_results = reader.readtext(crop_bin, detail=1,
                                      allowlist='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 ')

        plate_text = ""
        confidence = 0.0
        if ocr_results:
            # Pick highest-confidence detection
            best = max(ocr_results, key=lambda r: r[2])
            plate_text = clean_plate_text(best[1])
            confidence = round(best[2], 3)

        # Save annotated crop
        crop_path = ""
        if save_crops and plate_text:
            crop_path = os.path.join(OUTPUT_DIR, f"{base_name}_plate{idx+1}.jpg")
            cv2.imwrite(crop_path, crop)

        # Draw bounding box on original
        color = (0, 255, 0) if plate_text else (0, 0, 255)
        cv2.rectangle(img, (x1, y1), (x2, y2), color, 2)
        if plate_text:
            cv2.putText(img, plate_text, (x1, y1 - 8),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.75, color, 2)

        results.append({
            "plate_text" : plate_text,
            "confidence" : confidence,
            "bbox"       : (x1, y1, x2, y2),
            "crop_path"  : crop_path
        })

    # Save annotated full image
    annotated_path = os.path.join(OUTPUT_DIR, f"{base_name}_annotated.jpg")
    cv2.imwrite(annotated_path, img)

    return results


# ─────────────────────────────────────────────
# BATCH PROCESSING
# ─────────────────────────────────────────────
def process_folder(folder_path: str):
    """Process every image in a folder and write CSV summary."""
    supported = ('.jpg', '.jpeg', '.png', '.bmp', '.tiff')
    images    = [f for f in os.listdir(folder_path)
                 if f.lower().endswith(supported)]

    if not images:
        print(f"[WARN] No images found in: {folder_path}")
        return

    print(f"[INFO] Processing {len(images)} images from: {folder_path}\n")

    with open(RESULTS_CSV, 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(["Image", "Plate_Text", "Confidence", "Bbox", "Crop_Path", "Timestamp"])

        for i, fname in enumerate(images, 1):
            img_path = os.path.join(folder_path, fname)
            print(f"  [{i}/{len(images)}] {fname} ...", end=" ", flush=True)
            t0 = time.time()

            detections = detect_and_read(img_path)
            elapsed    = round(time.time() - t0, 2)

            if detections:
                for d in detections:
                    writer.writerow([
                        fname,
                        d['plate_text'],
                        d['confidence'],
                        d['bbox'],
                        d['crop_path'],
                        datetime.now().isoformat()
                    ])
                texts = [d['plate_text'] for d in detections if d['plate_text']]
                print(f"Found: {texts}  ({elapsed}s)")
            else:
                writer.writerow([fname, "NOT_DETECTED", 0, "", "", datetime.now().isoformat()])
                print(f"No plate detected  ({elapsed}s)")

    print(f"\n[INFO] Results saved to: {RESULTS_CSV}")
    print(f"[INFO] Annotated images in: {OUTPUT_DIR}/")


# ─────────────────────────────────────────────
# SINGLE IMAGE (quick test)
# ─────────────────────────────────────────────
def process_single(image_path: str):
    print(f"[INFO] Processing: {image_path}")
    detections = detect_and_read(image_path)
    if detections:
        for d in detections:
            print(f"  Plate : {d['plate_text']}")
            print(f"  Conf  : {d['confidence']}")
            print(f"  BBox  : {d['bbox']}")
    else:
        print("  No plate detected.")


# ─────────────────────────────────────────────
# ENTRY POINT
# ─────────────────────────────────────────────
if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("Usage:")
        print("  python detect_plate.py <image_path>          # single image")
        print("  python detect_plate.py --folder <folder>     # batch processing")
        sys.exit(0)

    if sys.argv[1] == "--folder" and len(sys.argv) >= 3:
        process_folder(sys.argv[2])
    else:
        process_single(sys.argv[1])
