# 🚗 Vehicle Number Plate Recognition (ANPR)

**Algorithm :** Haar Cascade Plate Detection + EasyOCR  
**Dataset    :** UFPR-ALPR (4500 images) or own plate photos  
**Tools      :** Python · OpenCV · EasyOCR  

---

## 📁 Project Structure

```
anpr_project/
│
├── detect_plate.py       ← Main script  (single image & batch)
├── live_detection.py     ← Webcam / video  real-time ANPR
├── evaluate.py           ← Accuracy metrics against ground truth
├── requirements.txt      ← pip dependencies
│
├── utils/
│   └── helpers.py        ← Pre-processing, drawing, text utils
│
├── sample_plates/        ← Put your test images here
└── output/               ← Annotated images + results CSV saved here
```

---

## ⚙️ Installation

```bash
# 1. Create a virtual environment (recommended)
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# 2. Install dependencies  (only 2 pip libs needed!)
pip install -r requirements.txt
```

> **First run:** EasyOCR downloads its English model (~100 MB). Internet required once.

---

## 🚀 Usage

### Single Image
```bash
python detect_plate.py path/to/car.jpg
```

### Batch Processing (whole folder)
```bash
python detect_plate.py --folder sample_plates/
```
Results are saved to `output/results.csv`  
Annotated images are saved to `output/`

### Live Webcam
```bash
python live_detection.py          # default webcam (index 0)
python live_detection.py 1        # secondary webcam
python live_detection.py video.mp4
```
Press **Q** to quit · **S** to save screenshot

---

## 📊 Evaluate Accuracy

Prepare a ground-truth CSV:
```
image_name,true_plate
car001.jpg,MH12AB1234
car002.jpg,KA05CD5678
```

Run:
```bash
python evaluate.py --gt ground_truth.csv --results output/results.csv
```

Sample output:
```
==================================================
          ANPR EVALUATION REPORT
==================================================
  Total images       : 100
  Plates detected    : 87   (87.0%)
  Exact matches      : 74
  Accuracy (exact)   : 74.00%
  Avg CER            : 0.0812  (lower = better)
==================================================
```

---

## 🔬 Algorithm Pipeline

```
Input Image
    │
    ▼
Grayscale + Histogram Equalisation
    │
    ▼
Haar Cascade Detector   ←  haarcascade_russian_plate_number.xml
  (detectMultiScale)
    │
    ▼
Crop Plate Region  +  2× Upscale  +  Otsu Binarisation
    │
    ▼
EasyOCR (English, allowlist A-Z 0-9)
    │
    ▼
Clean Text  →  Output  (CSV / annotated image / console)
```

---

## 🗂️ UFPR-ALPR Dataset

- **Download :** https://web.inf.ufpr.br/vri/databases/ufpr-alpr/
- 4500 images across urban, road, and parking scenarios
- Ground-truth label files included (`.txt` per image)
- Convert to CSV format expected by `evaluate.py`:
  ```
  image_name, true_plate
  ```

---

## 🛠️ Haar Cascade Used

`haarcascade_russian_plate_number.xml`  
Bundled with OpenCV (`cv2.data.haarcascades`). Works well on most international rectangular plates.

---

## 📌 Notes

| Parameter         | Value          | Effect                          |
|-------------------|----------------|---------------------------------|
| scaleFactor       | 1.1            | Detect at multiple scales       |
| minNeighbors      | 4              | Reduce false positives          |
| minSize           | (60, 20)       | Ignore tiny detections          |
| OCR upscale       | 2×             | Improves character recognition  |
| Binarisation      | Otsu           | Handles varying lighting        |

Tune `minNeighbors` up (less false positives) or down (fewer misses) based on your dataset.

---

## 📄 License
For academic / educational use. UFPR-ALPR dataset has its own license — see their website.
