"""
Live / Webcam ANPR
Real-time plate detection using webcam or video file.
"""

import cv2
import easyocr
import re
import time
import os

# ─── CONFIG ───────────────────────────────────
HAAR_PATH    = cv2.data.haarcascades + "haarcascade_russian_plate_number.xml"
OCR_INTERVAL = 0.5        # seconds between OCR calls (avoid lag)
OUTPUT_DIR   = "output"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# ─── INIT ─────────────────────────────────────
plate_cascade = cv2.CascadeClassifier(HAAR_PATH)
print("[INFO] Loading EasyOCR...")
reader = easyocr.Reader(['en'], gpu=False)
print("[INFO] EasyOCR ready. Press Q to quit, S to save screenshot.\n")


def clean_text(text):
    return re.sub(r'[^A-Z0-9]', '', text.upper())


def run_live(source=0):
    """
    source: 0 = webcam, or pass a video file path e.g. 'test.mp4'
    """
    cap = cv2.VideoCapture(source)
    if not cap.isOpened():
        print(f"[ERROR] Cannot open video source: {source}")
        return

    last_ocr_time = 0
    last_plates   = []
    frame_count   = 0

    while True:
        ret, frame = cap.read()
        if not ret:
            print("[INFO] Stream ended.")
            break

        frame_count += 1
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        gray = cv2.equalizeHist(gray)

        # ── Detect plates (every frame, fast) ──
        plates = plate_cascade.detectMultiScale(
            gray, scaleFactor=1.1, minNeighbors=4,
            minSize=(60, 20), maxSize=(400, 120)
        )

        now = time.time()
        run_ocr = (now - last_ocr_time) >= OCR_INTERVAL

        current_plates = []

        for (x, y, w, h) in plates:
            pad = 5
            x1, y1 = max(0, x-pad), max(0, y-pad)
            x2, y2 = min(frame.shape[1], x+w+pad), min(frame.shape[0], y+h+pad)
            crop = frame[y1:y2, x1:x2]

            plate_text = ""
            confidence = 0.0

            if run_ocr and crop.size > 0:
                crop_g = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
                crop_g = cv2.resize(crop_g, None, fx=2, fy=2,
                                    interpolation=cv2.INTER_CUBIC)
                _, crop_b = cv2.threshold(crop_g, 0, 255,
                                          cv2.THRESH_BINARY + cv2.THRESH_OTSU)
                ocr_out = reader.readtext(
                    crop_b, detail=1,
                    allowlist='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 '
                )
                if ocr_out:
                    best = max(ocr_out, key=lambda r: r[2])
                    plate_text = clean_text(best[1])
                    confidence = best[2]
                    current_plates.append(plate_text)

            # Draw bounding box
            color = (0, 220, 0) if plate_text else (0, 100, 255)
            cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
            if plate_text:
                label = f"{plate_text}  {confidence:.2f}"
                cv2.putText(frame, label, (x1, y1 - 8),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)

        if run_ocr:
            last_ocr_time = now
            if current_plates:
                last_plates = current_plates

        # ── HUD overlay ──
        cv2.putText(frame, "ANPR - Live", (10, 28),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 255, 0), 2)
        cv2.putText(frame, f"Frame: {frame_count}", (10, 55),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.55, (200, 200, 200), 1)
        if last_plates:
            cv2.putText(frame, f"Last: {', '.join(last_plates)}", (10, 80),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 255, 255), 1)

        cv2.imshow("ANPR - Live Detection", frame)

        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):
            break
        elif key == ord('s'):
            fname = os.path.join(OUTPUT_DIR, f"screenshot_{frame_count}.jpg")
            cv2.imwrite(fname, frame)
            print(f"[INFO] Screenshot saved: {fname}")

    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    import sys
    src = sys.argv[1] if len(sys.argv) > 1 else 0
    # If src is a digit string, convert to int (webcam index)
    if isinstance(src, str) and src.isdigit():
        src = int(src)
    run_live(src)
