"""
utils/helpers.py  –  Shared utilities for the ANPR project
"""

import cv2
import os
import re
import numpy as np


# ─────────────────────────────────────────────
# IMAGE PRE-PROCESSING
# ─────────────────────────────────────────────

def preprocess_for_detection(img: np.ndarray) -> np.ndarray:
    """
    Convert to grayscale + histogram equalisation.
    Used before feeding into Haar Cascade.
    """
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    return cv2.equalizeHist(gray)


def preprocess_crop_for_ocr(crop: np.ndarray) -> np.ndarray:
    """
    Upscale + binarise a plate crop before EasyOCR.
    Returns a binary (white text on black or vice-versa) image.
    """
    gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
    # 2× upscale preserves thin stroke details
    gray = cv2.resize(gray, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC)
    # Otsu binarisation
    _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    return binary


def deskew(img: np.ndarray) -> np.ndarray:
    """
    Correct slight tilt in a plate crop using moments.
    """
    coords = np.column_stack(np.where(img > 0))
    if coords.shape[0] < 5:
        return img
    angle = cv2.minAreaRect(coords)[-1]
    if angle < -45:
        angle = -(90 + angle)
    else:
        angle = -angle
    (h, w) = img.shape[:2]
    M = cv2.getRotationMatrix2D((w // 2, h // 2), angle, 1.0)
    return cv2.warpAffine(img, M, (w, h),
                          flags=cv2.INTER_CUBIC,
                          borderMode=cv2.BORDER_REPLICATE)


# ─────────────────────────────────────────────
# TEXT UTILS
# ─────────────────────────────────────────────

def clean_plate_text(text: str) -> str:
    """Remove everything except uppercase letters and digits."""
    return re.sub(r'[^A-Z0-9]', '', text.upper()).strip()


def is_valid_plate(text: str, min_len: int = 4, max_len: int = 10) -> bool:
    """Basic sanity check on recognised plate string."""
    return min_len <= len(text) <= max_len and bool(re.search(r'\d', text))


# ─────────────────────────────────────────────
# FILE UTILS
# ─────────────────────────────────────────────

def list_images(folder: str) -> list:
    """Return sorted list of image paths in a folder."""
    exts = {'.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.webp'}
    paths = []
    for f in sorted(os.listdir(folder)):
        if os.path.splitext(f)[1].lower() in exts:
            paths.append(os.path.join(folder, f))
    return paths


def ensure_dir(path: str):
    os.makedirs(path, exist_ok=True)


# ─────────────────────────────────────────────
# VISUALISATION
# ─────────────────────────────────────────────

def draw_detections(img: np.ndarray, detections: list) -> np.ndarray:
    """
    Draw bounding boxes + plate text on a copy of img.
    detections: list of dicts with keys plate_text, bbox (x1,y1,x2,y2), confidence
    """
    vis = img.copy()
    for d in detections:
        x1, y1, x2, y2 = d['bbox']
        text = d.get('plate_text', '')
        conf = d.get('confidence', 0)
        color = (0, 200, 0) if text else (0, 0, 200)
        cv2.rectangle(vis, (x1, y1), (x2, y2), color, 2)
        if text:
            label = f"{text}  {conf:.2f}"
            cv2.putText(vis, label, (x1, max(0, y1 - 8)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
    return vis
